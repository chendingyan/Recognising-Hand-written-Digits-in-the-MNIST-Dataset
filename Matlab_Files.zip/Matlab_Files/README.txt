Only have to modify SolveMNIST_Gradient.m

Contents of the remaining files:

evaluate_gB.m: Evaluate the functions & gradients
mnist.mat:     Training & testing data with respect to random Fourier features
mnist_original.mat:
               The original image data

